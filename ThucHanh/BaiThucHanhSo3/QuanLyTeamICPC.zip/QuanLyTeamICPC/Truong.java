package ThucHanh.BaiThucHanhSo3.QuanLyTeamICPC;

public class Truong {
    private String vietTat;
    private String tenTruong;

    public Truong(String vietTat, String tenTruong) {
        this.vietTat = vietTat;
        this.tenTruong = tenTruong;
    }

    public String getVietTat() {
        return vietTat;
    }

    public String getTenTruong() {
        return tenTruong;
    }
}
